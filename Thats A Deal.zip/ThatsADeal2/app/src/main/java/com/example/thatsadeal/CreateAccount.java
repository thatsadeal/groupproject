package com.example.thatsadeal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.SignUpCallback;

public class CreateAccount extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        final EditText email = findViewById(R.id.txtEmailAddress);
        final EditText username = findViewById(R.id.txtUserName);
        final EditText fname = findViewById(R.id.txtFname);
        final EditText lname = findViewById(R.id.txtLname);
        final EditText birthday = findViewById(R.id.txtBirthday);
        final EditText password = findViewById(R.id.txtPassword);
        EditText confirmedpass = findViewById(R.id.txtConfirmPass);



        final Button btnCreate = findViewById(R.id.btnCreateAccount);
        btnCreate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                // Create the ParseUser
                ParseUser user = new ParseUser();
                // Set core properties
                user.setUsername(username.getText().toString());
                user.setPassword(password.getText().toString());
                user.setEmail(email.getText().toString());
                // Set custom properties
                user.put("fName", fname.getText().toString());
                user.put("lName", lname.getText().toString());
                user.put("bDay", birthday.getText().toString());

                // Invoke signUpInBackground
                user.signUpInBackground(new SignUpCallback() {
                    public void done(ParseException e) {
                        if (e == null) {
                            ParseUser currentUser = ParseUser.getCurrentUser();
                            if(currentUser != null){
                                /*Intent intent = new Intent(CreateAccount.this, RestaurantDeal.class);
                                startActivity(intent);*/
                            }else {
                                Toast.makeText(CreateAccount.this, "Error: Can't login into account.", Toast.LENGTH_LONG).show();
                            }

                        } else {
                            Toast.makeText(CreateAccount.this, "This account has already been created.", Toast.LENGTH_LONG).show();

                            // Sign up didn't succeed. Look at the ParseException
                            // to figure out what went wrong
                        }
                    }
                });
            }
        });
    }
}
