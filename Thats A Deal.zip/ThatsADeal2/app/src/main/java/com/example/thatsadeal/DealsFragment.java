package com.example.thatsadeal;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thatsadeal.R;
import com.example.thatsadeal.Restaurant;
import com.example.thatsadeal.RestaurantAdpater;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.List;

public class DealsFragment extends Fragment {

    protected RecyclerView rView;
    protected DealAdapter adpater;
    protected List<Deals> deals;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        View root = inflater.inflate(R.layout.fragment_deal, container, false);


        return root;

    }

   /* public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState){
        rView = view.findViewById(R.id.rdView);
        deals = new ArrayList<>();
        adpater = new DealAdapter(getContext(), deals);
        rView.setAdapter(adpater);
        rView.setLayoutManager(new LinearLayoutManager(getContext()));

        ParseQuery<Deals> query = ParseQuery.getQuery("Deals");
        query.findInBackground(new FindCallback<Deals>() {
            @Override
            public void done(List<Deals> deals, ParseException e) {
                if(e == null){
                    adpater.clear();
                    adpater.addAll(deals);
                }else {

                }
            }
        });
    }*/

}