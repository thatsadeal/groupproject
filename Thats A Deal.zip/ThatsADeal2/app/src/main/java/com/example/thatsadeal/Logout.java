package com.example.thatsadeal;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.parse.ParseUser;


/* *
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Logout.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link Logout#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Logout extends Fragment {
    ParseUser currentUser = ParseUser.getCurrentUser();

    public Logout() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //final Button button = container.view.findViewById("n");
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_logout, container, false);
    }


 public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState){

        final Button button = view.findViewById(R.id.btnLogout);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ParseUser.logOut();
                Intent i = new Intent(getContext(), MainActivity.class);
                startActivity(i);
            }
        });

    }



}
