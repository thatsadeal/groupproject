package com.example.thatsadeal;


import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RestaurantAdpater extends RecyclerView.Adapter<RestaurantAdpater.ViewHolder> {
    private Context context;
    private List<Restaurant> restaurant;


    public RestaurantAdpater(Context context, List<Restaurant> restaurant){

        this.context = context;
        this.restaurant = restaurant;
    }

    @NonNull
    @Override
    public RestaurantAdpater.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.restaurant_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RestaurantAdpater.ViewHolder holder, int position) {
    Restaurant restaurants = restaurant.get(position);
        //Restaurant r = new Restaurant();
    holder.bind(restaurants);
    }

    public void clear(){
        restaurant.clear();
        notifyDataSetChanged();
    }

    public void addAll(List<Restaurant> restaurants){
        restaurant.addAll(restaurants);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return restaurant.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        private TextView txtName;
        private TextView txtAdd;
        private TextView txtNum;
        private TextView hid;
        public ViewHolder(@NonNull View itemView){
            super(itemView);

            txtName = itemView.findViewById(R.id.txtrName);
            txtNum = itemView.findViewById(R.id.txtrNum);
            txtAdd = itemView.findViewById(R.id.txtrAddress);
            hid = itemView.findViewById(R.id.hidden_id);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    RestaurantDeal.myBundle.putString("restaurant_id", hid.getText().toString());
                    Fragment fragment = new DealsFragment();

                }
            });
        }

        public void bind(Restaurant restaurant){
            txtName.setText(restaurant.getName());
            txtNum.setText(restaurant.getPhoneNumber());
            txtAdd.setText(restaurant.getAddress());
            hid.setText(restaurant.getKeyObjid());
        }
    }
}
