package com.example.thatsadeal.ui.tools;

import android.content.Intent;
import android.net.Uri;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.thatsadeal.MainActivity;
import com.example.thatsadeal.R;
import com.parse.ParseUser;

import java.io.File;


public class ToolsFragment extends Fragment {

    private ToolsViewModel toolsViewModel;
    public String photoFileName = "photo.jpg";
    File photoFile;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        toolsViewModel =
                ViewModelProviders.of(this).get(ToolsViewModel.class);
        View root = inflater.inflate(R.layout.fragment_settings, container, false);
        //final TextView textView = root.findViewById(R.id.text_settings);
       /* toolsViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });*/
        return root;
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState){
        final ParseUser currentUser = ParseUser.getCurrentUser();
        final EditText efname = view.findViewById(R.id.editFname);
        final EditText elname = view.findViewById(R.id.editLname);
        final EditText email = view.findViewById(R.id.editEmail);
        final EditText bday = view.findViewById(R.id.editBirthday);
        final Button button = view.findViewById(R.id.btnSaveChanges);
        

        efname.setText(currentUser.get("fName").toString());
        elname.setText(currentUser.get("lName").toString());
        email.setText(currentUser.get("email").toString());
        bday.setText(currentUser.get("bDay").toString());
    //once button is pressed
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                currentUser.put("fName", efname.getText().toString());
                currentUser.put("lName", elname.getText().toString());
                currentUser.put("email", email.getText().toString());
                currentUser.put("bDay", bday.getText().toString());
                currentUser.saveInBackground();
            //take the user back to the
                Intent i = new Intent(getContext(), MainActivity.class);
                startActivity(i);
            }
        });


    }
}